class User{
  String?_name;
  String? _email;
  String? _address;
  int? _id;
  int? _age;

  int get myId{
    return _id ?? 0;
  }

  set myId(int mId){
    _id = mId;
  }


  loginUser(){

  }

  signUpUser(){

  }

  logoutUser(){

  }

  updateUserInfo(){

  }

  changProfilePic(){

  }
}

void main(){

  /*User u = User(5, "Raman", "r@gmail.com", 16, "dfgbskjdbsdsbvkjsd");

  u._address;*/

}